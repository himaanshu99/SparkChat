# Unichat boilerplace

This is a modded creat-react-app project. It comes with:

- A manifest with correct packages
- Useless files taken out
- Needed folder structure
- CSS
